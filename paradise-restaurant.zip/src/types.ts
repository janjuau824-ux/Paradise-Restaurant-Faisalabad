export interface Dish {
  id: string;
  name: string;
  nameUrdu?: string;
  category: 'bbq' | 'karahi' | 'specialties' | 'roti' | 'starters' | 'desserts';
  description: string;
  pricePlaceholder: string;
  isSignature: boolean;
  isSpicy?: boolean;
  spicyLevel?: number; // 1 to 3
  image: string;
  tags: string[];
  rating: number;
}

export interface Feature {
  id: string;
  title: string;
  titleUrdu: string;
  description: string;
  iconName: string;
}

export interface Review {
  id: string;
  author: string;
  location: string;
  rating: number;
  date: string;
  comment: string;
  dishRecommended?: string;
  verified: boolean;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: 'all' | 'bbq' | 'ambiance' | 'family';
  image: string;
}

export interface ReservationState {
  name: string;
  phone: string;
  date: string;
  time: string;
  guests: number;
  seatingPreference: 'family' | 'outdoor' | 'main_hall' | 'executive';
  specialRequests: string;
}

export interface ContactState {
  name: string;
  phone: string;
  email: string;
  message: string;
}
