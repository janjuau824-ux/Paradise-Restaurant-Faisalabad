import React, { useState } from 'react';
import { Utensils, Search, Flame, Eye, Sparkles, Filter } from 'lucide-react';
import { ALL_MENU_ITEMS } from '../data/restaurantData';
import { Dish } from '../types';

interface FullMenuProps {
  onSelectDish: (dish: Dish) => void;
  onOpenReservation: () => void;
}

export const FullMenu: React.FC<FullMenuProps> = ({ onSelectDish, onOpenReservation }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [onlySpicy, setOnlySpicy] = useState<boolean>(false);

  const categories = [
    { id: 'all', label: 'All Dishes', labelUrdu: 'تمام ڈشز' },
    { id: 'bbq', label: 'BBQ & Grill', labelUrdu: 'بی بی کیو' },
    { id: 'karahi', label: 'Karahis & Handi', labelUrdu: 'کڑاہی و ہانڈی' },
    { id: 'specialties', label: 'Desi Specialties', labelUrdu: 'خاص دیسی' },
    { id: 'roti', label: 'Naan & Tandoor', labelUrdu: 'نان و روٹی' },
    { id: 'starters', label: 'Drinks & Starters', labelUrdu: 'مشروبات' },
    { id: 'desserts', label: 'Desserts', labelUrdu: 'میٹھے' },
  ];

  const filteredDishes = ALL_MENU_ITEMS.filter((dish) => {
    const matchesCategory = selectedCategory === 'all' || dish.category === selectedCategory;
    const matchesSearch =
      dish.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      dish.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (dish.nameUrdu && dish.nameUrdu.includes(searchQuery));
    const matchesSpicy = !onlySpicy || (dish.isSpicy && (dish.spicyLevel ?? 0) > 0);

    return matchesCategory && matchesSearch && matchesSpicy;
  });

  return (
    <section id="menu" className="py-20 lg:py-28 bg-[#161b1e] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 space-y-4">
          <div className="inline-flex items-center space-x-2 text-amber-400 font-mono text-xs uppercase tracking-widest bg-amber-500/10 px-3.5 py-1.5 rounded-full border border-amber-500/20">
            <Utensils className="w-3.5 h-3.5" />
            <span>Interactive Menu</span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-white tracking-tight">
            Explore Paradise <span className="text-gold-gradient italic">Specialities</span>
          </h2>

          <p className="text-amber-100/70 text-base">
            Browse our complete selection of authentic Desi curries, tandoori breads, and charcoal grills.
          </p>
        </div>

        {/* Search & Filter Controls Bar */}
        <div className="bg-charcoal-card p-4 sm:p-6 rounded-2xl border border-gold/20 shadow-xl mb-10 space-y-4">
          <div className="flex flex-col md:flex-row gap-4 justify-between items-center">
            {/* Search Bar */}
            <div className="relative w-full md:w-96">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-amber-400" />
              <input
                type="text"
                placeholder="Search dish, e.g., Karahi, Malai Boti, Naan..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#121619] border border-gold/30 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white placeholder-amber-200/50 focus:outline-none focus:border-amber-400 transition-colors"
              />
            </div>

            {/* Quick Filters */}
            <div className="flex items-center space-x-4 w-full md:w-auto justify-end">
              <label className="flex items-center space-x-2 text-xs font-semibold text-amber-200 cursor-pointer bg-[#121619] px-3.5 py-2 rounded-xl border border-white/10 hover:border-gold/30">
                <input
                  type="checkbox"
                  checked={onlySpicy}
                  onChange={(e) => setOnlySpicy(e.target.checked)}
                  className="rounded accent-amber-500 w-4 h-4"
                />
                <Flame className="w-4 h-4 text-rose-400" />
                <span>Spicy Dishes Only</span>
              </label>

              <span className="text-xs text-amber-300/60 font-mono">
                Showing {filteredDishes.length} items
              </span>
            </div>
          </div>

          {/* Category Tabs */}
          <div className="flex items-center space-x-2 overflow-x-auto pb-2 scrollbar-none pt-2 border-t border-white/5">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold whitespace-nowrap transition-all flex items-center space-x-2 cursor-pointer ${
                  selectedCategory === cat.id
                    ? 'bg-gradient-to-r from-amber-500 to-amber-700 text-slate-950 font-bold shadow-lg shadow-amber-950/50'
                    : 'bg-[#121619] text-amber-100/80 hover:text-white hover:bg-emerald-950/60 border border-white/10'
                }`}
              >
                <span>{cat.label}</span>
                <span className="opacity-70 font-serif text-[11px]">({cat.labelUrdu})</span>
              </button>
            ))}
          </div>
        </div>

        {/* Menu Items Grid */}
        {filteredDishes.length === 0 ? (
          <div className="text-center py-16 bg-charcoal-card rounded-2xl border border-white/10">
            <Utensils className="w-12 h-12 text-amber-400/40 mx-auto mb-3" />
            <h3 className="text-lg font-bold text-white">No dishes found</h3>
            <p className="text-xs text-amber-200/60 mt-1">Try adjusting your search terms or filters.</p>
            <button
              onClick={() => {
                setSelectedCategory('all');
                setSearchQuery('');
                setOnlySpicy(false);
              }}
              className="mt-4 px-4 py-2 rounded-lg bg-amber-500 text-slate-950 font-bold text-xs"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredDishes.map((dish) => (
              <div
                key={dish.id}
                className="bg-charcoal p-4 rounded-xl border border-gold/15 hover:border-gold/50 transition-all flex flex-col justify-between group hover:bg-[#1a2024]"
              >
                <div>
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h4 className="font-serif font-bold text-base text-white group-hover:text-amber-300 transition-colors">
                        {dish.name}
                      </h4>
                      {dish.nameUrdu && (
                        <p className="text-xs text-amber-400/80 font-serif font-semibold">
                          {dish.nameUrdu}
                        </p>
                      )}
                    </div>
                    <span className="text-xs font-mono text-amber-300 bg-amber-500/10 px-2 py-1 rounded border border-amber-500/20">
                      {dish.pricePlaceholder}
                    </span>
                  </div>

                  <p className="text-xs text-amber-100/70 line-clamp-2 leading-relaxed mb-3">
                    {dish.description}
                  </p>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-white/5 text-xs">
                  <span className="text-[11px] text-emerald-300/80 font-mono">
                    ★ {dish.rating} / 5
                  </span>

                  <button
                    onClick={() => onSelectDish(dish)}
                    className="text-amber-400 hover:text-white font-semibold flex items-center space-x-1 transition-colors cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>View Details</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

      </div>
    </section>
  );
};
