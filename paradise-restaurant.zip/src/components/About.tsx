import React from 'react';
import { Award, ShieldCheck, Heart, Sparkles, MapPin, Phone, ChefHat } from 'lucide-react';
import { RESTAURANT_INFO } from '../data/restaurantData';

export const About: React.FC = () => {
  return (
    <section id="about" className="py-20 lg:py-28 bg-[#161b1e] relative overflow-hidden">
      {/* Background Subtle Accent Glows */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-900/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-amber-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Image Column */}
          <div className="lg:col-span-6 relative">
            <div className="relative rounded-2xl overflow-hidden border border-gold/30 gold-glow">
              <img
                src="/src/assets/images/restaurant_ambiance_1786464870299.jpg"
                alt="Paradise Restaurant Faisalabad Ambiance"
                className="w-full h-[400px] sm:h-[500px] object-cover hover:scale-105 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#121619] via-transparent to-transparent opacity-80" />
            </div>

            {/* Floating Experience Badge */}
            <div className="absolute -bottom-6 -right-2 sm:right-6 bg-deep-green border-2 border-gold-bright p-5 rounded-2xl shadow-2xl backdrop-blur-md max-w-xs">
              <div className="flex items-center space-x-3">
                <div className="p-3 bg-amber-500 rounded-xl text-slate-950 font-bold">
                  <ChefHat className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-2xl font-serif font-bold text-white">Authentic Desi</div>
                  <div className="text-xs text-amber-300 font-medium">Faisalabad Culinary Landmark</div>
                </div>
              </div>
            </div>

            {/* Urdu Tag Badge */}
            <div className="absolute -top-4 -left-2 bg-amber-500 text-slate-950 px-4 py-2 rounded-lg font-serif font-bold text-sm shadow-lg">
              روایتی ذائقہ اور خاندانی ماحول
            </div>
          </div>

          {/* Text Content Column */}
          <div className="lg:col-span-6 space-y-6">
            <div className="inline-flex items-center space-x-2 text-amber-400 font-mono text-xs uppercase tracking-widest bg-amber-500/10 px-3.5 py-1.5 rounded-full border border-amber-500/20">
              <Sparkles className="w-3.5 h-3.5" />
              <span>About Paradise Restaurant</span>
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-bold text-white leading-tight">
              Crafting Unforgettable Desi Culinary Memories in <span className="text-gold-gradient italic">Faisalabad</span>
            </h2>

            <p className="text-amber-100/80 text-base leading-relaxed">
              At <strong className="text-amber-300">Paradise Restaurant</strong>, we take immense pride in preserving the vibrant legacy of Pakistani Desi and BBQ cooking. Located in the heart of Faisalabad, our kitchen is driven by a passion for slow-cooked Karahis, live charcoal-grilled kebabs, and warm Punjabi hospitality.
            </p>

            <p className="text-amber-100/70 text-sm leading-relaxed">
              Every single meal is prepared using pure home-style spices, fresh hand-picked mutton & chicken, and traditional clay handis. Whether you are hosting a family gathering, celebrating a milestone, or enjoying an outdoor dinner under the night sky, Paradise Restaurant offers an ambiance that feels like home.
            </p>

            {/* Core Values Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="glass-panel p-4 rounded-xl border border-gold/20 flex items-start space-x-3">
                <div className="p-2 bg-amber-500/20 text-amber-400 rounded-lg shrink-0 mt-0.5">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">100% Fresh & Halal</h4>
                  <p className="text-xs text-amber-200/70 mt-1">Daily sourced meat and organic hand-ground spices.</p>
                </div>
              </div>

              <div className="glass-panel p-4 rounded-xl border border-gold/20 flex items-start space-x-3">
                <div className="p-2 bg-amber-500/20 text-amber-400 rounded-lg shrink-0 mt-0.5">
                  <Heart className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">Family First Dining</h4>
                  <p className="text-xs text-amber-200/70 mt-1">Separate private hall for family comfort and privacy.</p>
                </div>
              </div>
            </div>

            {/* Quick Contact & Rating */}
            <div className="pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-4">
              <div>
                <div className="text-xs text-amber-300 font-mono">For Inquiries & Table Booking:</div>
                <a
                  href={`tel:${RESTAURANT_INFO.phone}`}
                  className="text-xl font-bold text-white hover:text-amber-400 transition-colors flex items-center space-x-2 mt-0.5"
                >
                  <Phone className="w-5 h-5 text-amber-400 animate-bounce" />
                  <span>{RESTAURANT_INFO.phone}</span>
                </a>
              </div>

              <div className="text-right">
                <div className="text-xs text-amber-300 font-mono">Customer Rating</div>
                <div className="text-xl font-bold text-amber-400 flex items-center space-x-1 justify-end">
                  <span>★ {RESTAURANT_INFO.rating}</span>
                  <span className="text-xs text-amber-200 font-normal">({RESTAURANT_INFO.totalReviewsCount} reviews)</span>
                </div>
              </div>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
