import React, { useState, useEffect } from 'react';
import { Phone, Utensils, Menu as MenuIcon, X, Calendar, MapPin, Star } from 'lucide-react';
import { RESTAURANT_INFO } from '../data/restaurantData';

interface NavbarProps {
  onOpenReservation: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenReservation }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 30) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'About', href: '#about' },
    { name: 'Signatures', href: '#signatures' },
    { name: 'Menu', href: '#menu' },
    { name: 'Features', href: '#features' },
    { name: 'Reviews', href: '#reviews' },
    { name: 'Gallery', href: '#gallery' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <>
      {/* Top Notification / Quick Contact Bar */}
      <div className="bg-deep-green text-cream text-xs py-2 px-4 border-b border-gold/20 hidden md:block">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-6">
            <span className="flex items-center text-amber-200">
              <MapPin className="w-3.5 h-3.5 text-amber-400 mr-1" />
              {RESTAURANT_INFO.locationCity}
            </span>
            <span className="flex items-center text-amber-200">
              <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400 mr-1" />
              Rating: <strong className="ml-1 text-white">{RESTAURANT_INFO.rating}/5</strong> ({RESTAURANT_INFO.totalReviewsCount} Reviews)
            </span>
          </div>
          <div className="flex items-center space-x-4">
            <a 
              href={`tel:${RESTAURANT_INFO.phone}`}
              className="flex items-center text-amber-300 hover:text-white transition-colors font-medium"
            >
              <Phone className="w-3.5 h-3.5 mr-1.5 animate-pulse" />
              Call Us: {RESTAURANT_INFO.phone}
            </a>
            <span className="text-amber-400/40">|</span>
            <span className="text-amber-100/80 font-mono">Pakistani, BBQ & Desi Food</span>
          </div>
        </div>
      </div>

      {/* Main Sticky Header */}
      <header
        className={`sticky top-0 z-40 transition-all duration-300 ${
          isScrolled
            ? 'bg-[#121619]/95 backdrop-blur-md shadow-2xl py-3 border-b border-gold/30'
            : 'bg-[#121619]/80 backdrop-blur-sm py-4 border-b border-white/10'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center">
          {/* Logo */}
          <a href="#home" className="flex items-center space-x-3 group">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-400 via-amber-600 to-emerald-900 p-0.5 shadow-lg group-hover:scale-105 transition-transform">
              <div className="w-full h-full bg-[#0b2b1e] rounded-full flex items-center justify-center">
                <Utensils className="w-5 h-5 text-amber-400" />
              </div>
            </div>
            <div>
              <div className="flex items-baseline space-x-1.5">
                <span className="font-serif text-xl sm:text-2xl font-bold tracking-wide text-white group-hover:text-amber-300 transition-colors">
                  PARADISE
                </span>
                <span className="text-xs font-semibold uppercase tracking-widest text-amber-400 font-mono">
                  Restaurant
                </span>
              </div>
              <p className="text-[10px] text-amber-200/80 font-serif leading-none tracking-wider">
                فردوس ریسٹورنٹ • Faisalabad
              </p>
            </div>
          </a>

          {/* Desktop Nav Links */}
          <nav className="hidden lg:flex items-center space-x-6 text-sm font-medium">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-amber-100/80 hover:text-amber-400 transition-colors py-1 relative after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-0.5 after:bg-amber-400 hover:after:w-full after:transition-all"
              >
                {link.name}
              </a>
            ))}
          </nav>

          {/* Action Buttons */}
          <div className="hidden sm:flex items-center space-x-3">
            <a
              href={`tel:${RESTAURANT_INFO.phone}`}
              className="px-3.5 py-2 rounded-lg bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-700/50 text-amber-300 text-xs font-semibold flex items-center space-x-2 transition-all"
            >
              <Phone className="w-3.5 h-3.5" />
              <span className="hidden md:inline">{RESTAURANT_INFO.phone}</span>
            </a>

            <button
              onClick={onOpenReservation}
              className="px-5 py-2.5 rounded-lg bg-gradient-to-r from-amber-500 via-amber-600 to-amber-700 hover:from-amber-400 hover:to-amber-600 text-slate-950 font-bold text-xs uppercase tracking-wider shadow-lg shadow-amber-900/30 hover:shadow-amber-500/20 transform hover:-translate-y-0.5 transition-all flex items-center space-x-2 cursor-pointer"
            >
              <Calendar className="w-4 h-4 text-slate-950" />
              <span>Reserve Table</span>
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex items-center space-x-2 lg:hidden">
            <button
              onClick={onOpenReservation}
              className="px-3 py-1.5 rounded-md bg-amber-500 text-slate-950 text-xs font-bold sm:hidden flex items-center space-x-1"
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>Reserve</span>
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg bg-emerald-950/80 border border-gold/30 text-amber-400 hover:text-white focus:outline-none"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <MenuIcon className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Menu Overlay */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex flex-col bg-[#121619]/98 backdrop-blur-xl border-b border-gold/40 animate-fadeIn">
          <div className="flex justify-between items-center p-4 border-b border-white/10">
            <div className="flex items-center space-x-2">
              <Utensils className="w-6 h-6 text-amber-400" />
              <span className="font-serif text-lg font-bold text-white">Paradise Restaurant</span>
            </div>
            <button
              onClick={() => setMobileMenuOpen(false)}
              className="p-2 rounded-lg bg-emerald-950 text-amber-400"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto px-6 py-6 space-y-4">
            <div className="text-xs text-amber-400 font-mono uppercase tracking-widest mb-2">Navigation</div>
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="block text-lg font-medium text-amber-100 hover:text-amber-400 py-2 border-b border-white/5"
              >
                {link.name}
              </a>
            ))}

            <div className="pt-6 space-y-3">
              <a
                href={`tel:${RESTAURANT_INFO.phone}`}
                className="w-full py-3 rounded-xl bg-emerald-900/60 border border-emerald-600/50 text-amber-300 font-semibold flex items-center justify-center space-x-2"
              >
                <Phone className="w-4 h-4" />
                <span>Call {RESTAURANT_INFO.phone}</span>
              </a>

              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenReservation();
                }}
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-700 text-slate-950 font-bold uppercase tracking-wider text-sm shadow-xl flex items-center justify-center space-x-2"
              >
                <Calendar className="w-5 h-5" />
                <span>Book a Table Now</span>
              </button>
            </div>

            <div className="pt-6 text-center text-xs text-amber-200/60">
              <p>📍 {RESTAURANT_INFO.locationCity}</p>
              <p className="mt-1">★ 4.7/5 rating from {RESTAURANT_INFO.totalReviewsCount} happy guests</p>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
