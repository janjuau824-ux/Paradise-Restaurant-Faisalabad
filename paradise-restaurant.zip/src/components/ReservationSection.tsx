import React, { useState } from 'react';
import { Calendar, Clock, Users, Phone, CheckCircle, Sparkles, MapPin, MessageSquare } from 'lucide-react';
import { RESTAURANT_INFO } from '../data/restaurantData';
import { ReservationState } from '../types';

export const ReservationSection: React.FC = () => {
  const [form, setForm] = useState<ReservationState>({
    name: '',
    phone: '',
    date: new Date().toISOString().split('T')[0],
    time: '20:00',
    guests: 4,
    seatingPreference: 'family',
    specialRequests: '',
  });

  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);
  const [resCode, setResCode] = useState<string>('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.phone) return;

    const code = `PARADISE-${Math.floor(1000 + Math.random() * 9000)}`;
    setResCode(code);
    setIsSubmitted(true);
  };

  const constructWhatsAppLink = () => {
    const text = encodeURIComponent(
      `Hello Paradise Restaurant! I would like to confirm my Table Reservation.\n\nBooking ID: ${resCode}\nName: ${form.name}\nPhone: ${form.phone}\nDate: ${form.date}\nTime: ${form.time}\nGuests: ${form.guests}\nSeating: ${form.seatingPreference.toUpperCase()}\nSpecial Requests: ${form.specialRequests || 'None'}`
    );
    return `https://wa.me/${RESTAURANT_INFO.whatsappPhone}?text=${text}`;
  };

  return (
    <section id="reserve" className="py-20 lg:py-28 bg-[#161b1e] relative overflow-hidden">
      {/* Glow Effects */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-emerald-900/20 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Info Column */}
          <div className="lg:col-span-5 space-y-6 text-center lg:text-left">
            <div className="inline-flex items-center space-x-2 text-amber-400 font-mono text-xs uppercase tracking-widest bg-amber-500/10 px-3.5 py-1.5 rounded-full border border-amber-500/20">
              <Calendar className="w-3.5 h-3.5" />
              <span>Instant Table Booking</span>
            </div>

            <h2 className="text-3xl sm:text-5xl font-serif font-bold text-white tracking-tight">
              Reserve Your Table at <span className="text-gold-gradient italic">Paradise</span>
            </h2>

            <p className="text-amber-100/80 text-base leading-relaxed">
              Ensure a seamless dining experience for your family, friends, or business partners. Booking ahead guarantees zero waiting time and personalized table setup.
            </p>

            <div className="p-6 rounded-2xl bg-charcoal-card border border-gold/30 space-y-4">
              <div className="flex items-center space-x-4">
                <div className="p-3 bg-emerald-950 text-amber-400 rounded-xl border border-gold/30">
                  <Phone className="w-6 h-6 animate-pulse" />
                </div>
                <div className="text-left">
                  <div className="text-xs text-amber-300 font-mono">Direct Phone Reservation</div>
                  <a href={`tel:${RESTAURANT_INFO.phone}`} className="text-xl font-bold text-white hover:text-amber-400">
                    {RESTAURANT_INFO.phone}
                  </a>
                </div>
              </div>

              <div className="pt-3 border-t border-white/10 text-xs text-amber-200/70 text-left space-y-1 font-mono">
                <p>📍 {RESTAURANT_INFO.locationCity}</p>
                <p>⏰ Open Daily: {RESTAURANT_INFO.openingHoursPlaceholder}</p>
              </div>
            </div>
          </div>

          {/* Right Form Column */}
          <div className="lg:col-span-7 bg-charcoal-card p-6 sm:p-10 rounded-3xl border border-gold/30 gold-glow relative">
            {isSubmitted ? (
              <div className="py-12 text-center space-y-6">
                <CheckCircle className="w-16 h-16 text-emerald-400 mx-auto animate-bounce" />
                
                <div>
                  <h3 className="text-2xl font-serif font-bold text-white">Reservation Confirmed!</h3>
                  <p className="text-amber-300 font-mono text-sm mt-1">Booking Reference: <strong className="text-white bg-amber-500/20 px-3 py-1 rounded border border-amber-500/40">{resCode}</strong></p>
                </div>

                <div className="p-4 rounded-xl bg-emerald-950/60 border border-emerald-700/40 text-xs text-amber-100 space-y-2 text-left max-w-md mx-auto font-mono">
                  <p>👤 Name: <span className="text-white font-bold">{form.name}</span></p>
                  <p>📞 Phone: <span className="text-white font-bold">{form.phone}</span></p>
                  <p>📅 Date & Time: <span className="text-white font-bold">{form.date} at {form.time}</span></p>
                  <p>👥 Guests: <span className="text-white font-bold">{form.guests} People</span> ({form.seatingPreference.toUpperCase()} Section)</p>
                </div>

                <div className="flex flex-col sm:flex-row justify-center gap-3 pt-2">
                  <a
                    href={constructWhatsAppLink()}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center space-x-2 shadow-lg"
                  >
                    <MessageSquare className="w-4 h-4" />
                    <span>Send via WhatsApp</span>
                  </a>

                  <button
                    onClick={() => setIsSubmitted(false)}
                    className="px-6 py-3 rounded-xl bg-charcoal border border-gold/40 text-amber-300 hover:text-white text-xs font-bold"
                  >
                    Make Another Reservation
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-amber-200 mb-1">Full Name *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Usman Chaudhry"
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      className="w-full bg-[#121619] border border-gold/30 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-amber-200 mb-1">Mobile / Phone (+92) *</label>
                    <input
                      type="tel"
                      required
                      placeholder="+92 300 1234567"
                      value={form.phone}
                      onChange={(e) => setForm({ ...form, phone: e.target.value })}
                      className="w-full bg-[#121619] border border-gold/30 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-amber-200 mb-1">Date *</label>
                    <input
                      type="date"
                      required
                      value={form.date}
                      onChange={(e) => setForm({ ...form, date: e.target.value })}
                      className="w-full bg-[#121619] border border-gold/30 rounded-xl px-3 py-3 text-xs text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-amber-200 mb-1">Time *</label>
                    <input
                      type="time"
                      required
                      value={form.time}
                      onChange={(e) => setForm({ ...form, time: e.target.value })}
                      className="w-full bg-[#121619] border border-gold/30 rounded-xl px-3 py-3 text-xs text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-amber-200 mb-1">Number of Guests</label>
                    <select
                      value={form.guests}
                      onChange={(e) => setForm({ ...form, guests: parseInt(e.target.value) })}
                      className="w-full bg-[#121619] border border-gold/30 rounded-xl px-3 py-3 text-xs text-white focus:outline-none focus:border-amber-400"
                    >
                      {[1, 2, 3, 4, 5, 6, 8, 10, 12, 15, 20, 25, 30].map((num) => (
                        <option key={num} value={num}>
                          {num} {num === 1 ? 'Person' : 'Guests'}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-amber-200 mb-1">Seating Section Preference</label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {[
                      { id: 'family', label: 'Family Hall' },
                      { id: 'outdoor', label: 'Outdoor Lawn' },
                      { id: 'main_hall', label: 'Main Dining' },
                      { id: 'executive', label: 'Executive Lounge' },
                    ].map((sec) => (
                      <button
                        key={sec.id}
                        type="button"
                        onClick={() => setForm({ ...form, seatingPreference: sec.id as any })}
                        className={`p-2.5 rounded-xl text-xs font-semibold text-center border cursor-pointer transition-all ${
                          form.seatingPreference === sec.id
                            ? 'bg-amber-500 text-slate-950 border-amber-400 font-bold'
                            : 'bg-[#121619] text-amber-200/80 border-white/10 hover:border-gold/30'
                        }`}
                      >
                        {sec.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-amber-200 mb-1">Special Instructions / Requests</label>
                  <input
                    type="text"
                    placeholder="e.g. Birthday cake table, wheelchair accessibility, quiet area..."
                    value={form.specialRequests}
                    onChange={(e) => setForm({ ...form, specialRequests: e.target.value })}
                    className="w-full bg-[#121619] border border-gold/30 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-4 rounded-xl bg-gradient-to-r from-amber-500 via-amber-600 to-amber-700 hover:from-amber-400 hover:to-amber-600 text-slate-950 font-extrabold uppercase tracking-wider text-sm shadow-xl shadow-amber-950/60 cursor-pointer"
                >
                  Confirm Table Reservation
                </button>
              </form>
            )}
          </div>

        </div>
      </div>
    </section>
  );
};
