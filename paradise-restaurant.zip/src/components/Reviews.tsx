import React, { useState } from 'react';
import { Star, MessageSquare, CheckCircle, PlusCircle, User, ThumbsUp, Sparkles } from 'lucide-react';
import { CUSTOMER_REVIEWS, RESTAURANT_INFO } from '../data/restaurantData';
import { Review } from '../types';

export const Reviews: React.FC = () => {
  const [reviewsList, setReviewsList] = useState<Review[]>(CUSTOMER_REVIEWS);
  const [showReviewModal, setShowReviewModal] = useState<boolean>(false);
  
  // Review form state
  const [newAuthor, setNewAuthor] = useState('');
  const [newLocation, setNewLocation] = useState('');
  const [newRating, setNewRating] = useState(5);
  const [newComment, setNewComment] = useState('');
  const [newDish, setNewDish] = useState('');
  const [submitSuccess, setSubmitSuccess] = useState(false);

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAuthor || !newComment) return;

    const newRev: Review = {
      id: `rev-${Date.now()}`,
      author: newAuthor,
      location: newLocation || 'Faisalabad, Pakistan',
      rating: newRating,
      date: 'Just now',
      comment: newComment,
      dishRecommended: newDish || 'Malai Boti & Karahi',
      verified: true,
    };

    setReviewsList([newRev, ...reviewsList]);
    setSubmitSuccess(true);
    setTimeout(() => {
      setSubmitSuccess(false);
      setShowReviewModal(false);
      setNewAuthor('');
      setNewLocation('');
      setNewComment('');
      setNewDish('');
    }, 1500);
  };

  return (
    <section id="reviews" className="py-20 lg:py-28 bg-[#161b1e] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header & Rating Highlights */}
        <div className="flex flex-col lg:flex-row justify-between items-center gap-8 mb-16">
          <div className="space-y-4 text-center lg:text-left max-w-2xl">
            <div className="inline-flex items-center space-x-2 text-amber-400 font-mono text-xs uppercase tracking-widest bg-amber-500/10 px-3.5 py-1.5 rounded-full border border-amber-500/20">
              <Star className="w-3.5 h-3.5 fill-amber-400" />
              <span>Customer Voice & Reviews</span>
            </div>

            <h2 className="text-3xl sm:text-5xl font-serif font-bold text-white tracking-tight">
              Loved by Foodies Across <span className="text-gold-gradient italic">Faisalabad</span>
            </h2>

            <p className="text-amber-100/70 text-base">
              Real opinions from families, food lovers, and guests who dined at Paradise Restaurant.
            </p>
          </div>

          {/* Rating Score Box */}
          <div className="bg-charcoal-card p-6 rounded-2xl border border-gold/30 gold-glow flex items-center space-x-6 text-center sm:text-left">
            <div className="p-4 bg-gradient-to-br from-amber-500 to-amber-700 text-slate-950 font-serif font-bold text-4xl rounded-xl shadow-lg">
              {RESTAURANT_INFO.rating}
            </div>
            <div>
              <div className="flex items-center space-x-1 text-amber-400 mb-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-amber-400" />
                ))}
              </div>
              <div className="text-sm font-bold text-white">
                {RESTAURANT_INFO.totalReviewsCount} Verified Reviews
              </div>
              <div className="text-xs text-amber-200/60 font-mono">
                98% Positive Dining Experience
              </div>
            </div>

            <button
              onClick={() => setShowReviewModal(true)}
              className="hidden sm:flex px-4 py-2.5 rounded-xl bg-emerald-950 hover:bg-emerald-900 border border-gold/40 text-amber-300 text-xs font-bold items-center space-x-2 transition-all cursor-pointer"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Write Review</span>
            </button>
          </div>
        </div>

        {/* Reviews Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {reviewsList.map((rev) => (
            <div
              key={rev.id}
              className="bg-charcoal p-6 sm:p-8 rounded-2xl border border-gold/20 hover:border-gold/50 transition-all shadow-lg flex flex-col justify-between"
            >
              <div className="space-y-4">
                {/* Author & Rating Header */}
                <div className="flex justify-between items-start">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 rounded-full bg-emerald-950 border border-gold/40 flex items-center justify-center text-amber-400 font-serif font-bold">
                      {rev.author.charAt(0)}
                    </div>
                    <div>
                      <h4 className="font-bold text-white text-base flex items-center space-x-2">
                        <span>{rev.author}</span>
                        {rev.verified && (
                          <CheckCircle className="w-4 h-4 text-emerald-400" title="Verified Customer" />
                        )}
                      </h4>
                      <p className="text-xs text-amber-200/60">{rev.location} • {rev.date}</p>
                    </div>
                  </div>

                  <div className="flex items-center text-amber-400 space-x-0.5 bg-amber-500/10 px-2.5 py-1 rounded-full border border-amber-500/20">
                    <Star className="w-3.5 h-3.5 fill-amber-400" />
                    <span className="text-xs font-bold ml-1">{rev.rating}.0</span>
                  </div>
                </div>

                {/* Comment */}
                <p className="text-amber-100/90 text-sm leading-relaxed italic">
                  "{rev.comment}"
                </p>
              </div>

              {/* Recommended Dish Tag */}
              {rev.dishRecommended && (
                <div className="mt-6 pt-4 border-t border-white/5 flex items-center justify-between text-xs text-amber-300/80">
                  <span className="font-mono text-emerald-400">
                    Recommended: <strong className="text-white">{rev.dishRecommended}</strong>
                  </span>
                  <ThumbsUp className="w-3.5 h-3.5 text-amber-400" />
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Mobile Leave Review Button */}
        <div className="mt-10 text-center sm:hidden">
          <button
            onClick={() => setShowReviewModal(true)}
            className="w-full py-3 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs uppercase tracking-wider flex items-center justify-center space-x-2"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Leave a Review</span>
          </button>
        </div>

      </div>

      {/* Review Modal */}
      {showReviewModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
          <div className="bg-charcoal-card p-6 sm:p-8 rounded-2xl border border-gold/40 max-w-md w-full shadow-2xl relative space-y-4">
            <div className="flex justify-between items-center border-b border-white/10 pb-4">
              <h3 className="text-xl font-serif font-bold text-white flex items-center space-x-2">
                <MessageSquare className="w-5 h-5 text-amber-400" />
                <span>Write a Guest Review</span>
              </h3>
              <button
                onClick={() => setShowReviewModal(false)}
                className="text-amber-200/60 hover:text-white text-lg font-bold"
              >
                ✕
              </button>
            </div>

            {submitSuccess ? (
              <div className="py-8 text-center space-y-3">
                <CheckCircle className="w-12 h-12 text-emerald-400 mx-auto animate-bounce" />
                <h4 className="text-lg font-bold text-white">Thank You!</h4>
                <p className="text-xs text-amber-200/80">Your review has been published successfully.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmitReview} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-amber-200 mb-1">Your Full Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Tariq Mehmood"
                    value={newAuthor}
                    onChange={(e) => setNewAuthor(e.target.value)}
                    className="w-full bg-[#121619] border border-gold/30 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-amber-200 mb-1">Location in Faisalabad</label>
                  <input
                    type="text"
                    placeholder="e.g. D-Ground / Canal Road"
                    value={newLocation}
                    onChange={(e) => setNewLocation(e.target.value)}
                    className="w-full bg-[#121619] border border-gold/30 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-amber-200 mb-1">Rating</label>
                  <div className="flex items-center space-x-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setNewRating(star)}
                        className="p-1 cursor-pointer"
                      >
                        <Star
                          className={`w-6 h-6 ${
                            star <= newRating ? 'text-amber-400 fill-amber-400' : 'text-slate-600'
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-amber-200 mb-1">Recommended Dish</label>
                  <input
                    type="text"
                    placeholder="e.g. Mutton Karahi / Malai Boti"
                    value={newDish}
                    onChange={(e) => setNewDish(e.target.value)}
                    className="w-full bg-[#121619] border border-gold/30 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-amber-200 mb-1">Your Review *</label>
                  <textarea
                    required
                    rows={3}
                    placeholder="Share your dining experience, food quality, or staff behavior..."
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    className="w-full bg-[#121619] border border-gold/30 rounded-xl p-3 text-sm text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-700 text-slate-950 font-bold uppercase tracking-wider text-xs shadow-lg cursor-pointer"
                >
                  Post Review
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </section>
  );
};
