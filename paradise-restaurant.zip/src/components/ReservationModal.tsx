import React, { useState } from 'react';
import { Calendar, X, Phone, CheckCircle, MessageSquare } from 'lucide-react';
import { RESTAURANT_INFO } from '../data/restaurantData';

interface ReservationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ReservationModal: React.FC<ReservationModalProps> = ({ isOpen, onClose }) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [time, setTime] = useState('20:00');
  const [guests, setGuests] = useState(4);
  const [seating, setSeating] = useState('family');
  const [submitted, setSubmitted] = useState(false);
  const [resCode, setResCode] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone) return;
    setResCode(`PR-${Math.floor(1000 + Math.random() * 9000)}`);
    setSubmitted(true);
  };

  const getWhatsApp = () => {
    const text = encodeURIComponent(
      `Hello Paradise Restaurant! Table Booking Request:\nCode: ${resCode}\nName: ${name}\nPhone: ${phone}\nDate: ${date}\nTime: ${time}\nGuests: ${guests}\nSeating: ${seating}`
    );
    return `https://wa.me/${RESTAURANT_INFO.whatsappPhone}?text=${text}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="bg-charcoal-card p-6 sm:p-8 rounded-3xl border border-gold/40 max-w-lg w-full shadow-2xl relative space-y-4">
        
        {/* Header */}
        <div className="flex justify-between items-center border-b border-white/10 pb-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-amber-500 rounded-xl text-slate-950 font-bold">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xl font-serif font-bold text-white">Reserve Table</h3>
              <p className="text-xs text-amber-300 font-mono">Paradise Restaurant • Faisalabad</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full bg-black/40 text-amber-200/60 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {submitted ? (
          <div className="py-8 text-center space-y-4">
            <CheckCircle className="w-16 h-16 text-emerald-400 mx-auto animate-bounce" />
            <h4 className="text-2xl font-serif font-bold text-white">Table Reserved!</h4>
            <p className="text-xs text-amber-200/80 font-mono">
              Booking Ref: <strong className="text-amber-400">{resCode}</strong>
            </p>
            <p className="text-xs text-amber-100/70">
              We look forward to hosting you on <strong className="text-white">{date}</strong> at <strong className="text-white">{time}</strong> for <strong className="text-white">{guests} guests</strong>.
            </p>

            <div className="pt-4 flex flex-col sm:flex-row gap-3">
              <a
                href={getWhatsApp()}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3 rounded-xl bg-emerald-600 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center space-x-2"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Confirm on WhatsApp</span>
              </a>

              <button
                onClick={() => {
                  setSubmitted(false);
                  onClose();
                }}
                className="w-full py-3 rounded-xl bg-charcoal text-amber-300 border border-gold/30 text-xs font-bold"
              >
                Close Window
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-amber-200 mb-1">Full Name *</label>
              <input
                type="text"
                required
                placeholder="e.g. Salman Khan"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-[#121619] border border-gold/30 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-amber-200 mb-1">Phone Number (+92) *</label>
              <input
                type="tel"
                required
                placeholder="+92 329 8124444"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full bg-[#121619] border border-gold/30 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-amber-400"
              />
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold text-amber-200 mb-1">Date</label>
                <input
                  type="date"
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full bg-[#121619] border border-gold/30 rounded-xl p-2 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-amber-200 mb-1">Time</label>
                <input
                  type="time"
                  required
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  className="w-full bg-[#121619] border border-gold/30 rounded-xl p-2 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-amber-200 mb-1">Guests</label>
                <select
                  value={guests}
                  onChange={(e) => setGuests(parseInt(e.target.value))}
                  className="w-full bg-[#121619] border border-gold/30 rounded-xl p-2 text-xs text-white"
                >
                  {[2, 4, 6, 8, 10, 15, 20].map((num) => (
                    <option key={num} value={num}>
                      {num} Guests
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-amber-200 mb-1">Seating Section</label>
              <select
                value={seating}
                onChange={(e) => setSeating(e.target.value)}
                className="w-full bg-[#121619] border border-gold/30 rounded-xl p-2.5 text-xs text-white"
              >
                <option value="family">Family Hall (Private & Cozy)</option>
                <option value="outdoor">Outdoor Lawn Seating</option>
                <option value="main">Main Dining Hall</option>
                <option value="executive">Executive Lounge</option>
              </select>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-700 text-slate-950 font-bold uppercase tracking-wider text-xs shadow-lg cursor-pointer"
              >
                Submit Booking Request
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
