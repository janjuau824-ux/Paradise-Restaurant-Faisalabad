import React from 'react';
import { Star, Calendar, Utensils, ArrowRight, ShieldCheck, Flame, Users, Car } from 'lucide-react';
import { RESTAURANT_INFO } from '../data/restaurantData';

interface HeroProps {
  onOpenReservation: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenReservation }) => {
  return (
    <section id="home" className="relative min-h-[90vh] lg:min-h-screen flex items-center justify-center overflow-hidden bg-charcoal">
      {/* Background Image with Dark Luxury Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src="/src/assets/images/pakistani_food_hero_1786464854875.jpg"
          alt="Paradise Restaurant Pakistani Cuisine Feast"
          className="w-full h-full object-cover object-center scale-105 animate-pulse duration-10000"
          referrerPolicy="no-referrer"
        />
        {/* Deep Green Charcoal Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#121619] via-[#0b2b1e]/85 to-[#121619]/90" />
        <div className="absolute inset-0 bg-radial from-transparent via-[#121619]/60 to-[#121619]" />
      </div>

      {/* Hero Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-28 text-center flex flex-col items-center">
        {/* Rating Badge */}
        <div className="inline-flex items-center space-x-2 bg-emerald-950/90 border border-gold/40 px-4 py-2 rounded-full mb-6 backdrop-blur-md shadow-xl animate-fadeIn">
          <div className="flex items-center text-amber-400 space-x-1">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="w-4 h-4 fill-amber-400" />
            ))}
          </div>
          <span className="text-xs sm:text-sm font-semibold text-amber-200">
            {RESTAURANT_INFO.rating} / 5 Rating
          </span>
          <span className="text-amber-400/40">•</span>
          <span className="text-xs text-emerald-200 font-medium">
            {RESTAURANT_INFO.totalReviewsCount} Verified Reviews
          </span>
        </div>

        {/* Heading */}
        <h1 className="text-4xl sm:text-6xl lg:text-7xl font-serif font-bold text-white tracking-tight leading-tight max-w-5xl mb-4 drop-shadow-2xl">
          A Taste of <span className="text-gold-gradient italic">Paradise</span> in Faisalabad
        </h1>

        {/* Urdu Subtitle Badge */}
        <p className="text-amber-300 font-serif text-lg sm:text-xl md:text-2xl mb-6 font-medium tracking-wide">
          فردوس ریسٹورنٹ فیصل آباد — لذت اور روایت کا شاہکار
        </p>

        {/* English Subtitle */}
        <p className="text-amber-100/90 text-base sm:text-lg lg:text-xl max-w-3xl mb-10 leading-relaxed font-light">
          Experience authentic Pakistani gastronomy, sizzling charcoal BBQ platters, and traditional clay-handi Karahis crafted with time-honored family recipes and pure spices.
        </p>

        {/* Call to Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 w-full sm:w-auto mb-16">
          <button
            onClick={onOpenReservation}
            className="w-full sm:w-auto px-8 py-4 rounded-xl bg-gradient-to-r from-amber-500 via-amber-600 to-amber-700 hover:from-amber-400 hover:to-amber-600 text-slate-950 font-extrabold text-sm sm:text-base uppercase tracking-wider shadow-2xl shadow-amber-950/80 hover:shadow-amber-500/30 transform hover:-translate-y-1 transition-all flex items-center justify-center space-x-3 cursor-pointer"
          >
            <Calendar className="w-5 h-5 text-slate-950" />
            <span>Reserve Table Now</span>
          </button>

          <a
            href="#signatures"
            className="w-full sm:w-auto px-8 py-4 rounded-xl bg-emerald-950/80 hover:bg-emerald-900 border border-gold/40 hover:border-gold-bright text-amber-200 hover:text-white font-bold text-sm sm:text-base tracking-wider backdrop-blur-md transition-all flex items-center justify-center space-x-2 group"
          >
            <Utensils className="w-5 h-5 text-amber-400 group-hover:rotate-12 transition-transform" />
            <span>View Signature Dishes</span>
            <ArrowRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform text-amber-400" />
          </a>
        </div>

        {/* Key Features Strip */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-6 w-full max-w-5xl pt-8 border-t border-gold/20">
          <div className="glass-panel p-3 sm:p-4 rounded-xl flex items-center space-x-3 text-left">
            <div className="p-2.5 rounded-lg bg-amber-500/10 text-amber-400 shrink-0">
              <Flame className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-white">Authentic BBQ</h4>
              <p className="text-[11px] text-amber-200/70">Live Charcoal Grill</p>
            </div>
          </div>

          <div className="glass-panel p-3 sm:p-4 rounded-xl flex items-center space-x-3 text-left">
            <div className="p-2.5 rounded-lg bg-amber-500/10 text-amber-400 shrink-0">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-white">Family Dining</h4>
              <p className="text-[11px] text-amber-200/70">Private Hall & Lounge</p>
            </div>
          </div>

          <div className="glass-panel p-3 sm:p-4 rounded-xl flex items-center space-x-3 text-left">
            <div className="p-2.5 rounded-lg bg-amber-500/10 text-amber-400 shrink-0">
              <Car className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-white">Free Parking</h4>
              <p className="text-[11px] text-amber-200/70">Valet & Secure Lot</p>
            </div>
          </div>

          <div className="glass-panel p-3 sm:p-4 rounded-xl flex items-center space-x-3 text-left">
            <div className="p-2.5 rounded-lg bg-amber-500/10 text-amber-400 shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-white">100% Halal</h4>
              <p className="text-[11px] text-amber-200/70">Pure & Fresh Desi</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
