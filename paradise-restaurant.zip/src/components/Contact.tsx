import React, { useState } from 'react';
import { Phone, MapPin, Clock, Mail, Send, CheckCircle, MessageSquare } from 'lucide-react';
import { RESTAURANT_INFO } from '../data/restaurantData';
import { ContactState } from '../types';

export const Contact: React.FC = () => {
  const [form, setForm] = useState<ContactState>({
    name: '',
    phone: '',
    email: '',
    message: '',
  });

  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.phone) return;
    setSent(true);
    setTimeout(() => {
      setSent(false);
      setForm({ name: '', phone: '', email: '', message: '' });
    }, 4000);
  };

  return (
    <section id="contact" className="py-20 lg:py-28 bg-[#121619] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center space-x-2 text-amber-400 font-mono text-xs uppercase tracking-widest bg-amber-500/10 px-3.5 py-1.5 rounded-full border border-amber-500/20">
            <MapPin className="w-3.5 h-3.5" />
            <span>Find Us & Contact</span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-white tracking-tight">
            Get in Touch with <span className="text-gold-gradient italic">Paradise</span>
          </h2>

          <p className="text-amber-100/70 text-base">
            We are located conveniently in Faisalabad, Pakistan. Reach out for party bookings, event catering, or general questions.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          
          {/* Contact Details Cards */}
          <div className="lg:col-span-5 space-y-6">
            {/* Phone Card */}
            <div className="bg-charcoal-card p-6 rounded-2xl border border-gold/20 hover:border-gold-bright transition-all flex items-start space-x-4">
              <div className="p-3 bg-emerald-950 text-amber-400 rounded-xl border border-gold/30 shrink-0">
                <Phone className="w-6 h-6 animate-pulse" />
              </div>
              <div>
                <h4 className="text-sm font-mono text-amber-300">Phone Number</h4>
                <a href={`tel:${RESTAURANT_INFO.phone}`} className="text-xl font-bold text-white hover:text-amber-400 transition-colors block mt-1">
                  {RESTAURANT_INFO.phone}
                </a>
                <p className="text-xs text-amber-200/60 mt-1">Direct call or WhatsApp support</p>
              </div>
            </div>

            {/* Location Card */}
            <div className="bg-charcoal-card p-6 rounded-2xl border border-gold/20 hover:border-gold-bright transition-all flex items-start space-x-4">
              <div className="p-3 bg-emerald-950 text-amber-400 rounded-xl border border-gold/30 shrink-0">
                <MapPin className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-sm font-mono text-amber-300">Restaurant Location</h4>
                <p className="text-sm font-bold text-white mt-1 leading-snug">
                  {RESTAURANT_INFO.location}
                </p>
                <p className="text-xs text-amber-200/60 mt-1">Faisalabad, Punjab, Pakistan</p>
              </div>
            </div>

            {/* Hours Card */}
            <div className="bg-charcoal-card p-6 rounded-2xl border border-gold/20 hover:border-gold-bright transition-all flex items-start space-x-4">
              <div className="p-3 bg-emerald-950 text-amber-400 rounded-xl border border-gold/30 shrink-0">
                <Clock className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-sm font-mono text-amber-300">Opening Hours</h4>
                <p className="text-sm font-bold text-white mt-1">
                  {RESTAURANT_INFO.openingHoursPlaceholder}
                </p>
                <p className="text-xs text-amber-200/60 mt-1">Lunch, Dinner & Late Night BBQ</p>
              </div>
            </div>

            {/* Simulated Map Visual */}
            <div className="bg-charcoal-card rounded-2xl overflow-hidden border border-gold/20 p-4 text-center space-y-3">
              <div className="h-40 rounded-xl bg-slate-900 flex flex-col items-center justify-center p-4 relative overflow-hidden border border-white/10">
                <div className="absolute inset-0 bg-gradient-to-tr from-emerald-950 to-slate-900 opacity-90" />
                <MapPin className="w-10 h-10 text-amber-400 relative z-10 animate-bounce" />
                <span className="text-xs font-bold text-white relative z-10 mt-2">
                  Paradise Restaurant • Faisalabad
                </span>
                <span className="text-[10px] text-amber-200/70 relative z-10">
                  West Canal Road
                </span>
              </div>
              <a
                href={`https://maps.google.com/?q=Paradise+Restaurant+Faisalabad`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block text-xs font-bold text-amber-400 hover:text-white transition-colors"
              >
                ➔ Open Directions in Google Maps
              </a>
            </div>
          </div>

          {/* Contact Message Form */}
          <div className="lg:col-span-7 bg-charcoal-card p-6 sm:p-10 rounded-3xl border border-gold/30 gold-glow">
            <h3 className="text-2xl font-serif font-bold text-white mb-2">Send an Inquiry</h3>
            <p className="text-xs text-amber-100/70 mb-6">
              Have questions about party reservations, catering packages, or menu details? Leave a quick message below.
            </p>

            {sent ? (
              <div className="py-12 text-center space-y-3">
                <CheckCircle className="w-12 h-12 text-emerald-400 mx-auto animate-bounce" />
                <h4 className="text-xl font-bold text-white">Message Received!</h4>
                <p className="text-xs text-amber-200/80">Our manager in Faisalabad will get back to you shortly.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-amber-200 mb-1">Your Name *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Hammad Ali"
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      className="w-full bg-[#121619] border border-gold/30 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-amber-200 mb-1">Phone Number (+92) *</label>
                    <input
                      type="tel"
                      required
                      placeholder="+92 329 8124444"
                      value={form.phone}
                      onChange={(e) => setForm({ ...form, phone: e.target.value })}
                      className="w-full bg-[#121619] border border-gold/30 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-amber-200 mb-1">Email Address (Optional)</label>
                  <input
                    type="email"
                    placeholder="e.g. hammad@example.com"
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    className="w-full bg-[#121619] border border-gold/30 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-amber-200 mb-1">Message / Inquiry *</label>
                  <textarea
                    required
                    rows={4}
                    placeholder="Tell us what you would like to ask or organize..."
                    value={form.message}
                    onChange={(e) => setForm({ ...form, message: e.target.value })}
                    className="w-full bg-[#121619] border border-gold/30 rounded-xl p-4 text-sm text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-4 rounded-xl bg-gradient-to-r from-amber-500 via-amber-600 to-amber-700 hover:from-amber-400 hover:to-amber-600 text-slate-950 font-extrabold uppercase tracking-wider text-xs shadow-xl cursor-pointer flex items-center justify-center space-x-2"
                >
                  <Send className="w-4 h-4" />
                  <span>Send Message</span>
                </button>
              </form>
            )}
          </div>

        </div>
      </div>
    </section>
  );
};
