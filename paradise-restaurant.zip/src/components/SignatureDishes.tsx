import React from 'react';
import { Sparkles, Star, Flame, Eye, ShoppingBag } from 'lucide-react';
import { SIGNATURE_DISHES } from '../data/restaurantData';
import { Dish } from '../types';

interface SignatureDishesProps {
  onSelectDish: (dish: Dish) => void;
  onOpenReservation: () => void;
}

export const SignatureDishes: React.FC<SignatureDishesProps> = ({ onSelectDish, onOpenReservation }) => {
  return (
    <section id="signatures" className="py-20 lg:py-28 bg-[#121619] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center space-x-2 text-amber-400 font-mono text-xs uppercase tracking-widest bg-amber-500/10 px-3.5 py-1.5 rounded-full border border-amber-500/20">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Chef's Masterpieces</span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-white tracking-tight">
            Our <span className="text-gold-gradient italic">Signature</span> Culinary Creations
          </h2>

          <p className="text-amber-100/70 text-base">
            Handcrafted with freshly ground organic spices, charcoal fire, and authentic Desi Ghee in Faisalabad.
          </p>
          <p className="text-amber-300 font-serif text-lg font-medium">
            فردوس ریسٹورنٹ کے مشہور ترین شاہکار پکوان
          </p>
        </div>

        {/* 6 Signature Dishes Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {SIGNATURE_DISHES.map((dish) => (
            <div
              key={dish.id}
              className="bg-charcoal-card rounded-2xl overflow-hidden border border-gold/20 hover:border-gold-bright/60 transition-all duration-300 shadow-xl hover:shadow-2xl hover:shadow-amber-950/40 group flex flex-col justify-between"
            >
              <div>
                {/* Image & Badges */}
                <div className="relative h-60 overflow-hidden bg-slate-900">
                  <img
                    src={dish.image}
                    alt={dish.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#1a2024] via-transparent to-black/30" />

                  {/* Top Badges */}
                  <div className="absolute top-3 left-3 flex flex-wrap gap-2">
                    <span className="bg-amber-500 text-slate-950 font-bold text-[11px] uppercase tracking-wider px-2.5 py-1 rounded-md shadow-md">
                      Signature
                    </span>
                    {dish.spicyLevel !== undefined && dish.spicyLevel > 0 && (
                      <span className="bg-rose-950/90 text-rose-300 border border-rose-600/40 text-[11px] font-semibold px-2 py-1 rounded-md flex items-center space-x-1">
                        <Flame className="w-3 h-3 text-rose-400 fill-rose-400" />
                        <span>{'🌶️'.repeat(dish.spicyLevel)}</span>
                      </span>
                    )}
                  </div>

                  {/* Rating Tag */}
                  <div className="absolute top-3 right-3 bg-black/70 backdrop-blur-md text-amber-300 text-xs font-bold px-2.5 py-1 rounded-full border border-amber-400/30 flex items-center space-x-1">
                    <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                    <span>{dish.rating}</span>
                  </div>

                  {/* Urdu Name Overlay */}
                  {dish.nameUrdu && (
                    <div className="absolute bottom-3 right-3 bg-deep-green/90 text-amber-200 px-3 py-1 rounded-lg text-sm font-serif font-bold border border-gold/30">
                      {dish.nameUrdu}
                    </div>
                  )}
                </div>

                {/* Content */}
                <div className="p-6 space-y-3">
                  <div className="flex justify-between items-start">
                    <h3 className="text-xl font-serif font-bold text-white group-hover:text-amber-300 transition-colors">
                      {dish.name}
                    </h3>
                  </div>

                  <p className="text-amber-100/70 text-xs leading-relaxed line-clamp-3">
                    {dish.description}
                  </p>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-1.5 pt-2">
                    {dish.tags.map((tag, idx) => (
                      <span
                        key={idx}
                        className="text-[10px] font-mono bg-emerald-950/80 text-amber-300/90 border border-emerald-700/40 px-2 py-0.5 rounded"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Card Footer */}
              <div className="p-6 pt-0 border-t border-white/5 flex items-center justify-between mt-4">
                <span className="text-xs text-amber-300/80 font-mono italic">
                  {dish.pricePlaceholder}
                </span>

                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => onSelectDish(dish)}
                    className="p-2 rounded-lg bg-emerald-950 hover:bg-emerald-900 text-amber-300 border border-gold/30 text-xs font-semibold flex items-center space-x-1 cursor-pointer transition-colors"
                    title="View details"
                  >
                    <Eye className="w-4 h-4" />
                    <span className="hidden sm:inline">Details</span>
                  </button>

                  <button
                    onClick={onOpenReservation}
                    className="px-3.5 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold uppercase tracking-wider flex items-center space-x-1 transition-all cursor-pointer shadow-md"
                  >
                    <ShoppingBag className="w-3.5 h-3.5" />
                    <span>Order / Table</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
