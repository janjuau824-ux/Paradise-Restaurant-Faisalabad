import React from 'react';
import { Utensils, Phone, MapPin, Clock, ArrowUp, Star, Heart } from 'lucide-react';
import { RESTAURANT_INFO } from '../data/restaurantData';

interface FooterProps {
  onOpenReservation: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenReservation }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-deep-green-dark border-t border-gold/30 text-amber-100 pt-16 pb-8 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main 4-Column Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 pb-12 border-b border-white/10">
          
          {/* Column 1: Brand Info */}
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-full bg-amber-500 flex items-center justify-center text-slate-950 font-bold shadow-lg">
                <Utensils className="w-5 h-5" />
              </div>
              <div>
                <span className="font-serif text-2xl font-bold tracking-wide text-white block">
                  PARADISE
                </span>
                <span className="text-[10px] text-amber-300 font-mono uppercase tracking-widest block">
                  Restaurant • Faisalabad
                </span>
              </div>
            </div>

            <p className="text-xs text-amber-200/80 leading-relaxed font-serif italic">
              "فردوس ریسٹورنٹ — فیصل آباد میں دیسی کڑاہی اور بی بی کیو کا سب سے بہترین مرکز"
            </p>

            <p className="text-xs text-amber-100/70 leading-relaxed">
              Serving Faisalabad with authentic Pakistani gastronomy, live charcoal BBQ platters, and traditional clay-handi Karahis.
            </p>

            <div className="flex items-center space-x-2 text-xs text-amber-300 font-semibold pt-1">
              <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
              <span>{RESTAURANT_INFO.rating} / 5 Rating</span>
              <span className="text-amber-400/40">•</span>
              <span className="text-amber-100/80">{RESTAURANT_INFO.totalReviewsCount} Reviews</span>
            </div>
          </div>

          {/* Column 2: Quick Links */}
          <div className="space-y-3">
            <h4 className="text-sm font-mono uppercase tracking-widest text-amber-400 font-bold">
              Quick Navigation
            </h4>
            <ul className="space-y-2 text-xs font-medium">
              {[
                { name: 'Home', href: '#home' },
                { name: 'About Restaurant', href: '#about' },
                { name: 'Signature Dishes', href: '#signatures' },
                { name: 'Interactive Menu', href: '#menu' },
                { name: 'Features & Amenities', href: '#features' },
                { name: 'Guest Reviews', href: '#reviews' },
                { name: 'Photo Gallery', href: '#gallery' },
                { name: 'Contact & Location', href: '#contact' },
              ].map((link) => (
                <li key={link.name}>
                  <a
                    href={link.href}
                    className="text-amber-200/80 hover:text-amber-400 transition-colors flex items-center space-x-1.5"
                  >
                    <span className="text-amber-400 text-xs">▸</span>
                    <span>{link.name}</span>
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3: Contact & Location */}
          <div className="space-y-3">
            <h4 className="text-sm font-mono uppercase tracking-widest text-amber-400 font-bold">
              Contact Details
            </h4>
            
            <div className="space-y-3 text-xs">
              <div className="flex items-start space-x-2.5">
                <Phone className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <span className="block text-amber-300/80 text-[11px]">Phone Reservations:</span>
                  <a href={`tel:${RESTAURANT_INFO.phone}`} className="text-white font-bold text-sm hover:text-amber-400">
                    {RESTAURANT_INFO.phone}
                  </a>
                </div>
              </div>

              <div className="flex items-start space-x-2.5">
                <MapPin className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <span className="block text-amber-300/80 text-[11px]">Address:</span>
                  <p className="text-white font-medium">{RESTAURANT_INFO.location}</p>
                </div>
              </div>

              <div className="flex items-start space-x-2.5">
                <Clock className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <span className="block text-amber-300/80 text-[11px]">Hours:</span>
                  <p className="text-white font-medium">{RESTAURANT_INFO.openingHoursPlaceholder}</p>
                </div>
              </div>
            </div>

            <div className="pt-2">
              <button
                onClick={onOpenReservation}
                className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer"
              >
                Book Table Online
              </button>
            </div>
          </div>

          {/* Column 4: Cuisine & Placeholder Note */}
          <div className="space-y-3">
            <h4 className="text-sm font-mono uppercase tracking-widest text-amber-400 font-bold">
              Cuisine & Speciality
            </h4>
            <p className="text-xs text-amber-200/80 leading-relaxed">
              Specialized in Pakistani BBQ, Live Charcoal Grills, Clay Handi Karahis, fresh Tandoori breads, and family dining.
            </p>

            <div className="p-3 bg-[#121619] rounded-xl border border-white/10 text-[11px] text-amber-200/60 leading-normal font-mono">
              <strong>Official Notice:</strong> Social accounts and exact menu prices are available on request at the venue.
            </div>

            <div className="pt-2 text-center sm:text-left">
              <p className="text-[11px] text-amber-400/80 font-serif">
                100% Halal Desi Food • Faisalabad
              </p>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row justify-between items-center text-xs text-amber-200/60 gap-4">
          <p>© {new Date().getFullYear()} Paradise Restaurant, Faisalabad, Pakistan. All rights reserved.</p>

          <button
            onClick={scrollToTop}
            className="p-2.5 rounded-xl bg-emerald-950 border border-gold/30 text-amber-400 hover:text-white hover:bg-emerald-900 transition-colors flex items-center space-x-2 cursor-pointer"
          >
            <span>Back to Top</span>
            <ArrowUp className="w-4 h-4" />
          </button>
        </div>

      </div>
    </footer>
  );
};
