import React from 'react';
import { X, Star, Flame, ShoppingBag, Utensils } from 'lucide-react';
import { Dish } from '../types';

interface DishDetailModalProps {
  dish: Dish | null;
  onClose: () => void;
  onOpenReservation: () => void;
}

export const DishDetailModal: React.FC<DishDetailModalProps> = ({ dish, onClose, onOpenReservation }) => {
  if (!dish) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="bg-charcoal-card rounded-3xl border border-gold/40 max-w-lg w-full overflow-hidden shadow-2xl relative space-y-4">
        
        {/* Top Image */}
        <div className="relative h-64 bg-black">
          <img
            src={dish.image}
            alt={dish.name}
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#1a2024] via-transparent to-black/40" />

          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full bg-black/70 text-white hover:text-amber-400"
          >
            <X className="w-5 h-5" />
          </button>

          {dish.nameUrdu && (
            <div className="absolute bottom-4 right-4 bg-deep-green text-amber-300 font-serif font-bold text-base px-3 py-1 rounded-xl border border-gold/40">
              {dish.nameUrdu}
            </div>
          )}
        </div>

        {/* Content */}
        <div className="p-6 pt-2 space-y-4">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="text-2xl font-serif font-bold text-white">{dish.name}</h3>
              <div className="flex items-center space-x-2 text-xs text-amber-300 font-mono mt-1">
                <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                <span>{dish.rating} / 5 Customer Score</span>
              </div>
            </div>

            <span className="bg-amber-500/20 text-amber-300 px-3 py-1 rounded-lg border border-amber-500/30 text-xs font-mono font-bold">
              {dish.pricePlaceholder}
            </span>
          </div>

          <p className="text-amber-100/80 text-sm leading-relaxed">
            {dish.description}
          </p>

          {/* Tags */}
          <div className="flex flex-wrap gap-2 pt-2">
            {dish.tags.map((t, idx) => (
              <span
                key={idx}
                className="bg-emerald-950 text-amber-300 border border-emerald-700/50 text-xs px-2.5 py-1 rounded-md font-mono"
              >
                #{t}
              </span>
            ))}
          </div>

          <div className="pt-4 border-t border-white/10 flex items-center justify-between">
            <span className="text-xs text-amber-200/60 font-mono">
              Prepared Fresh Upon Order
            </span>

            <button
              onClick={() => {
                onClose();
                onOpenReservation();
              }}
              className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider flex items-center space-x-2"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Order / Reserve Table</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
