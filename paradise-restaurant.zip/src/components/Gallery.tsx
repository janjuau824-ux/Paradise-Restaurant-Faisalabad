import React, { useState } from 'react';
import { Camera, Eye, X, Sparkles } from 'lucide-react';
import { GALLERY_ITEMS } from '../data/restaurantData';
import { GalleryItem } from '../types';

export const Gallery: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'bbq' | 'ambiance' | 'family'>('all');
  const [activeItem, setActiveItem] = useState<GalleryItem | null>(null);

  const filterTabs = [
    { id: 'all', label: 'All Photos' },
    { id: 'bbq', label: 'BBQ & Karahi' },
    { id: 'ambiance', label: 'Ambiance' },
    { id: 'family', label: 'Family Dining' },
  ];

  const filteredItems = GALLERY_ITEMS.filter(
    (item) => selectedCategory === 'all' || item.category === selectedCategory
  );

  return (
    <section id="gallery" className="py-20 lg:py-28 bg-[#121619] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 space-y-4">
          <div className="inline-flex items-center space-x-2 text-amber-400 font-mono text-xs uppercase tracking-widest bg-amber-500/10 px-3.5 py-1.5 rounded-full border border-amber-500/20">
            <Camera className="w-3.5 h-3.5" />
            <span>Visual Showcase</span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-white tracking-tight">
            Glimpse of <span className="text-gold-gradient italic">Paradise</span>
          </h2>

          <p className="text-amber-100/70 text-base">
            Take a visual tour of our royal food, warm lighting, and family dining setup.
          </p>
        </div>

        {/* Filter Tabs */}
        <div className="flex justify-center items-center space-x-3 mb-10 overflow-x-auto pb-2">
          {filterTabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setSelectedCategory(tab.id as any)}
              className={`px-5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                selectedCategory === tab.id
                  ? 'bg-amber-500 text-slate-950 font-bold shadow-lg shadow-amber-950/50'
                  : 'bg-charcoal-card text-amber-200/80 hover:text-white border border-white/10'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Image Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              onClick={() => setActiveItem(item)}
              className="group relative h-72 rounded-2xl overflow-hidden border border-gold/20 hover:border-gold-bright cursor-pointer shadow-xl transition-all duration-300"
            >
              <img
                src={item.image}
                alt={item.title}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent opacity-60 group-hover:opacity-90 transition-opacity" />

              <div className="absolute bottom-4 left-4 right-4 p-2 transform translate-y-2 group-hover:translate-y-0 transition-transform">
                <span className="text-[10px] font-mono uppercase tracking-widest text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                  {item.category}
                </span>
                <h4 className="text-base font-serif font-bold text-white mt-1">
                  {item.title}
                </h4>
              </div>

              <div className="absolute top-4 right-4 p-2 bg-black/60 rounded-full text-amber-400 opacity-0 group-hover:opacity-100 transition-opacity">
                <Eye className="w-4 h-4" />
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Lightbox Modal */}
      {activeItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-fadeIn">
          <div className="relative max-w-4xl w-full bg-charcoal-card rounded-2xl overflow-hidden border border-gold/40 shadow-2xl">
            <button
              onClick={() => setActiveItem(null)}
              className="absolute top-4 right-4 z-10 p-2 rounded-full bg-black/70 text-white hover:text-amber-400"
            >
              <X className="w-6 h-6" />
            </button>

            <div className="relative h-[60vh] sm:h-[70vh]">
              <img
                src={activeItem.image}
                alt={activeItem.title}
                className="w-full h-full object-contain bg-black"
                referrerPolicy="no-referrer"
              />
            </div>

            <div className="p-6 bg-charcoal border-t border-white/10 flex justify-between items-center">
              <div>
                <h3 className="text-xl font-serif font-bold text-white">{activeItem.title}</h3>
                <p className="text-xs text-amber-200/60 font-mono mt-0.5">Paradise Restaurant Faisalabad</p>
              </div>
              <span className="px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-mono border border-amber-500/30">
                {activeItem.category.toUpperCase()}
              </span>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
