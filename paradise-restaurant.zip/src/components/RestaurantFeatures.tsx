import React from 'react';
import { Users, Sun, Accessibility, Car, CalendarCheck, Sparkles } from 'lucide-react';
import { FEATURES } from '../data/restaurantData';

interface RestaurantFeaturesProps {
  onOpenReservation: () => void;
}

export const RestaurantFeatures: React.FC<RestaurantFeaturesProps> = ({ onOpenReservation }) => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Users':
        return <Users className="w-7 h-7 text-amber-400" />;
      case 'Sun':
        return <Sun className="w-7 h-7 text-amber-400" />;
      case 'Accessibility':
        return <Accessibility className="w-7 h-7 text-amber-400" />;
      case 'Car':
        return <Car className="w-7 h-7 text-amber-400" />;
      case 'CalendarCheck':
        return <CalendarCheck className="w-7 h-7 text-amber-400" />;
      default:
        return <Sparkles className="w-7 h-7 text-amber-400" />;
    }
  };

  return (
    <section id="features" className="py-20 lg:py-28 bg-[#121619] relative overflow-hidden">
      {/* Decorative Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-emerald-950/20 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center space-x-2 text-amber-400 font-mono text-xs uppercase tracking-widest bg-amber-500/10 px-3.5 py-1.5 rounded-full border border-amber-500/20">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Hospitality & Amenities</span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-white tracking-tight">
            Designed for Your <span className="text-gold-gradient italic">Comfort & Happiness</span>
          </h2>

          <p className="text-amber-100/70 text-base">
            Every feature at Paradise Restaurant is crafted to offer guests in Faisalabad an exceptional dining environment.
          </p>
        </div>

        {/* 5 Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {FEATURES.map((feature, idx) => (
            <div
              key={feature.id}
              className={`bg-charcoal-card p-8 rounded-2xl border border-gold/20 hover:border-gold-bright transition-all duration-300 shadow-xl group hover:-translate-y-1 flex flex-col justify-between ${
                idx === 4 ? 'md:col-span-2 lg:col-span-1' : ''
              }`}
            >
              <div className="space-y-4">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-emerald-900 to-emerald-950 border border-gold/30 flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                  {getIcon(feature.iconName)}
                </div>

                <div className="flex justify-between items-baseline">
                  <h3 className="text-xl font-serif font-bold text-white group-hover:text-amber-300 transition-colors">
                    {feature.title}
                  </h3>
                  <span className="text-amber-400 font-serif font-bold text-sm">
                    {feature.titleUrdu}
                  </span>
                </div>

                <p className="text-amber-100/70 text-xs sm:text-sm leading-relaxed">
                  {feature.description}
                </p>
              </div>

              {feature.id === 'feat-reservations' && (
                <button
                  onClick={onOpenReservation}
                  className="mt-6 w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer"
                >
                  Book Table Now
                </button>
              )}
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
