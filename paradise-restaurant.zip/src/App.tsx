import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { SignatureDishes } from './components/SignatureDishes';
import { FullMenu } from './components/FullMenu';
import { RestaurantFeatures } from './components/RestaurantFeatures';
import { Reviews } from './components/Reviews';
import { Gallery } from './components/Gallery';
import { ReservationSection } from './components/ReservationSection';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { ReservationModal } from './components/ReservationModal';
import { DishDetailModal } from './components/DishDetailModal';
import { Dish } from './types';
import { RESTAURANT_INFO } from './data/restaurantData';
import { Phone, Calendar } from 'lucide-react';

export default function App() {
  const [isReservationOpen, setIsReservationOpen] = useState(false);
  const [selectedDish, setSelectedDish] = useState<Dish | null>(null);

  return (
    <div className="min-h-screen bg-[#121619] text-[#f4efe6] selection:bg-amber-500 selection:text-slate-950 font-sans antialiased">
      {/* Sticky Navbar */}
      <Navbar onOpenReservation={() => setIsReservationOpen(true)} />

      {/* Main Content Sections */}
      <main>
        {/* 1. Fullscreen Hero Section */}
        <Hero onOpenReservation={() => setIsReservationOpen(true)} />

        {/* 2. About Paradise Restaurant Section */}
        <About />

        {/* 3. Signature Dishes Section (6 dishes specified) */}
        <SignatureDishes
          onSelectDish={(dish) => setSelectedDish(dish)}
          onOpenReservation={() => setIsReservationOpen(true)}
        />

        {/* 4. Full Categorized Menu Section */}
        <FullMenu
          onSelectDish={(dish) => setSelectedDish(dish)}
          onOpenReservation={() => setIsReservationOpen(true)}
        />

        {/* 5. Restaurant Features & Hospitality */}
        <RestaurantFeatures onOpenReservation={() => setIsReservationOpen(true)} />

        {/* 6. Customer Reviews (4.7/5 & 865+ reviews) */}
        <Reviews />

        {/* 7. Gallery Section */}
        <Gallery />

        {/* 8. Online Table Reservation Section */}
        <ReservationSection />

        {/* 9. Contact & Location Section */}
        <Contact />
      </main>

      {/* Footer */}
      <Footer onOpenReservation={() => setIsReservationOpen(true)} />

      {/* Modals */}
      <ReservationModal
        isOpen={isReservationOpen}
        onClose={() => setIsReservationOpen(false)}
      />

      <DishDetailModal
        dish={selectedDish}
        onClose={() => setSelectedDish(null)}
        onOpenReservation={() => setIsReservationOpen(true)}
      />

      {/* Floating Action Bar for Mobile & Quick Call */}
      <div className="fixed bottom-4 right-4 z-40 flex flex-col space-y-2">
        <a
          href={`tel:${RESTAURANT_INFO.phone}`}
          className="p-3.5 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white shadow-2xl border-2 border-gold flex items-center justify-center transition-transform hover:scale-110 cursor-pointer"
          title={`Call ${RESTAURANT_INFO.phone}`}
        >
          <Phone className="w-6 h-6 animate-pulse" />
        </a>

        <button
          onClick={() => setIsReservationOpen(true)}
          className="p-3.5 rounded-full bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold shadow-2xl border-2 border-slate-900 flex items-center justify-center transition-transform hover:scale-110 cursor-pointer"
          title="Reserve Table"
        >
          <Calendar className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
}
